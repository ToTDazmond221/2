import pygame
import sys

pygame.init()
screen = pygame.display.set_mode((300, 300))
pygame.display.set_caption("Персонаж")
character_image = pygame.image.load("creature.png")
character_rect = character_image.get_rect()
character_rect.topleft = (0, 0)
while True:
    screen.fill((255, 255, 255))
    screen.blit(character_image, character_rect)
    pygame.display.flip()
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT:
                character_rect.x -= 10
            elif event.key == pygame.K_RIGHT:
                character_rect.x += 10
            elif event.key == pygame.K_UP:
                character_rect.y -= 10
            elif event.key == pygame.K_DOWN:
                character_rect.y += 10
